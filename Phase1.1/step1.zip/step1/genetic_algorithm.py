import numpy as np
import matplotlib.pyplot as plt
from step1.Fitness_function import fitness, normalize_coefficients, calculate_f1_score, calculate_f2_score


def roulette_wheel_selection(population, fitness_values):
    """
    population: chromosome list
    fitness_values: chromosome's fitness values
    output = chosen chromosome
    """
    # اینجا براساس برازندگی به هر عضو شانس انتخاب شدن داده میشه و به صورت تصادفی انتخاب صورت میگیره
    fitness_values = np.array(fitness_values, dtype=float)

    fitness_values = np.maximum(fitness_values, 0)

    total_fitness = np.sum(fitness_values)

    if total_fitness == 0:
        return population[np.random.randint(len(population))]

    probabilities = fitness_values / total_fitness

    selected_index = np.random.choice(
        len(population),
        p=probabilities
    )

    return population[selected_index]


def tournament_selection(population, fitness_values, tournament_size=3):
    # یک گروه 3 تایی انتخاب میشه هر بار و از بین این گروه اونی که بهترین فیتنس را داره انتخاب میشه
    selected_indices = np.random.choice(
        len(population),
        size=tournament_size,
        replace=False
    )

    tournament_fitness = [
        fitness_values[i]
        for i in selected_indices
    ]

    # finding best person
    winner_index = selected_indices[np.argmax(tournament_fitness)]

    return population[winner_index]


def uniform_crossover(parent1, parent2, crossover_rate=0.5):
    child1 = []
    child2 = []

    for gene1, gene2 in zip(parent1, parent2):

        if np.random.rand() < crossover_rate:
            child1.append(gene1)
            child2.append(gene2)
        else:
            child1.append(gene2)
            child2.append(gene1)

    return child1, child2


def arithmetic_crossover(parent1, parent2, alpha=None):
    parent1 = np.array(parent1)
    parent2 = np.array(parent2)

    if alpha is None:
        alpha = np.random.rand()

    child1 = alpha * parent1 + (1 - alpha) * parent2
    child2 = alpha * parent2 + (1 - alpha) * parent1

    return child1.tolist(), child2.tolist()


def inversion_mutation(chromosome, mutation_rate=0.05, low=0, high=10):
    mutated = np.array(chromosome, dtype=float)

    for i in range(len(mutated)):
        if np.random.rand() < mutation_rate:
            mutated[i] = high - mutated[i]

    # اعمال محدودیت بازه
    mutated = np.clip(mutated, low, high)

    return mutated.tolist()


def initialize_population(df_clean, pop_size=50, low=0, high=10):
    population = []
    fitness_values = []

    for _ in range(pop_size):
        chrom = np.random.uniform(low, high, size=11).tolist()
        fit = fitness(df_clean, chrom)
        population.append(chrom)
        fitness_values.append(fit)

    return population, fitness_values


def run_ga(df_clean, pop_size=50, generations=100,
           selection_method="tournament",
           crossover_method="arithmetic",
           crossover_rate=0.9,
           mutation_rate=0.05,
           tournament_size=3,
           elitism_rate=0.05,
           plot_convergence=True):

    population, fitness_values = initialize_population(df_clean, pop_size)

    best_fitness_history = []
    avg_fitness_history = []
    best_f1_history = []
    best_f2_history = []

    for gen in range(generations):
        # ذخیره بهترین‌ها
        elite_count = max(1, int(elitism_rate * pop_size))

        sorted_indices = np.argsort(fitness_values)[::-1]
        elites = [population[i] for i in sorted_indices[:elite_count]]
        elite_fitness = [fitness_values[i] for i in sorted_indices[:elite_count]]

        # ثبت تاریخچه بهترین فرد
        best_idx = sorted_indices[0]
        best_individual = population[best_idx]

        ai = best_individual[:6]
        bj = best_individual[6:]

        a_norm = normalize_coefficients(ai)
        b_norm = normalize_coefficients(bj)

        f1_arr = calculate_f1_score(df_clean, a_norm)
        f2_arr = calculate_f2_score(df_clean, b_norm)

        best_f1_history.append(np.mean(f1_arr))
        best_f2_history.append(np.mean(f2_arr))
        best_fitness_history.append(fitness_values[best_idx])
        avg_fitness_history.append(np.mean(fitness_values))


        new_population = []
        new_fitness = []

        #  اول نخبگان اضافه میشن
        new_population.extend(elites)
        new_fitness.extend(elite_fitness)

        # بقیه افراد تولید میشن
        while len(new_population) < pop_size:

            # Selection
            if selection_method == "tournament":
                parent1 = tournament_selection(population, fitness_values, tournament_size)
                parent2 = tournament_selection(population, fitness_values, tournament_size)

            elif selection_method == "roulette":
                parent1 = roulette_wheel_selection(population, fitness_values)
                parent2 = roulette_wheel_selection(population, fitness_values)

            else:
                raise ValueError("Invalid selection method")

            # Crossover
            if np.random.rand() < crossover_rate:

                if crossover_method == "arithmetic":
                    child1, child2 = arithmetic_crossover(parent1, parent2)

                elif crossover_method == "uniform":
                    child1, child2 = uniform_crossover(parent1, parent2)

                else:
                    raise ValueError("Invalid crossover method")

            else:
                child1, child2 = parent1[:], parent2[:]

            # Mutation
            child1 = inversion_mutation(child1, mutation_rate)
            child2 = inversion_mutation(child2, mutation_rate)

            # Fitness children
            fit1 = fitness(df_clean, child1)
            fit2 = fitness(df_clean, child2)

            new_population.append(child1)
            new_fitness.append(fit1)

            if len(new_population) < pop_size:
                new_population.append(child2)
                new_fitness.append(fit2)

        # new generation
        population = new_population
        fitness_values = new_fitness

    # best chromosome
    best_idx = np.argmax(fitness_values)
    if plot_convergence:
        plt.figure(figsize=(10, 5))
        plt.plot(best_fitness_history, label='Best Fitness', color='blue', linewidth=2)
        plt.xlabel('Generation')
        plt.ylabel('Fitness')
        plt.title('Convergence Plot of Genetic Algorithm (With Elitism)')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.show()

    return (population[best_idx],
            fitness_values[best_idx],
            best_fitness_history,
            avg_fitness_history,
            best_f1_history,
            best_f2_history)
